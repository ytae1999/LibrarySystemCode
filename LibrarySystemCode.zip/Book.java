import java.util.TreeSet;
/**
 * Write a description of class Book here.
 *
 * @author (2018315033태영준,2018210083노승욱, 2018210025현기호, 2018210059송주호)
 * @version (2019.11.29)
 */
public class Book
{
    private int CatalogueNumber;
    private String title;
    private String author;
    private Loan loan;
    
    public Book(String title, String author, int CatalogueNumber){
        this.CatalogueNumber = CatalogueNumber;
        this.title = title;
        this.author = author;
    }
    public Book getBook(int CatalogueNumber){
        
    }
    public void delLoan(){
        this.loan = null;
    }
    public void display(Book book){
        
    }
}
